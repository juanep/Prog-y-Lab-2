using Microsoft.VisualStudio.TestTools.UnitTesting;
using BibliotecaClases;
using System.Collections.Generic;

namespace UnitTest
{
  [TestClass]
  public class CentralitaTest
  {
    [TestMethod]
    public void HasInitList()
    {
      // Arrange
      Centralita centralita = new Centralita("Pepito SRL");

      // Act
      List<Llamada> llamadas = centralita.Llamadas;

      // Assert
      Assert.IsNotNull(llamadas);
    }

    [TestMethod]
    [ExpectedException(typeof(CentralitaException))]
    public void HasSameLlamadaLocal()
    {
      // Arrange
      Centralita centralita = new Centralita("Pepe asd");
      Llamada local = new Local("bs as", 3, "cordoba", 13);
      Llamada local2 = new Local("bs as", 3, "cordoba", 13);

      // Act
      try
      {
        centralita += local;
        centralita += local2;
      }
      catch (CentralitaException ex)
      {
        throw ex;
      }

      // Assert

    }
  }
}
