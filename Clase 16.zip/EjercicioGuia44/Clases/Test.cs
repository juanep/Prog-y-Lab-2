﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaClases
{
    public class Test
    {

        public bool TestB(Centralita c, Llamada llamada)
        {
            bool valido = true;

            if (llamada is Local)
            {
                foreach (Llamada llamadaAct in c.Llamadas)
                {
                    if ((llamadaAct.NroOrigen == llamada.NroOrigen) && (llamadaAct.NroDestino == llamada.NroDestino))
                    {
                        valido = false;
                    }
                }

            }

            if (!(valido))
            {
                throw new CentralitaException("Nro Origen y destino iguales", "Test", "TestA");
            }


            return valido;
        }

        /*c. Controlar mediante un nuevo método de test unitario que la excepción CentralitaExcepcion
se lance al intentar cargar una segunda llamada con solamente los mismos datos de origen y
destino de una llamada Provincial ya existente./*/

        public bool TestC(Centralita c, Llamada llamada)
        {
            bool valido = true;

            if (llamada is Provincial)
            {
                foreach (Llamada llamadaAct in c.Llamadas)
                {
                    if ((llamadaAct.NroOrigen == llamada.NroOrigen) && (llamadaAct.NroDestino == llamada.NroDestino))
                    {
                        valido = false;
                    }
                }

            }

            if (!(valido))
            {
                throw new CentralitaException("Nro Origen y destino iguales", "Test", "TestA");
            }


            return valido;
        }


        public bool TestD(Centralita c, Llamada llamada)
        {

        }



    }
}
