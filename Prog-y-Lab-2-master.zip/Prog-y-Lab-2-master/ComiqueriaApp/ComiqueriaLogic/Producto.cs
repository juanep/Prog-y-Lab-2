﻿using System;
using System.Text;

namespace ComiqueriaLogic
{
    public abstract class Producto
    {
        private Guid codigo;
        private int stock;
        private double precio;
        private string descripcion;

        public int Stock
        {
            get { return this.stock; }
            set
            {
                if(value >= 0)
                {
                    this.stock = value;
                }
            }
        }

        public double Precio
        {
            get { return this.precio; }
        }

        public string Descripcion
        {
            get { return this.descripcion; }
        }

        protected Producto(string descripcion, int stock, double precio)
        {
            this.descripcion = descripcion;
            this.stock = stock;
            this.precio = precio;
            this.codigo = Guid.NewGuid();
        }

        public static explicit operator Guid(Producto p)
        {
            if(p != null)
            {
                return p.codigo;
            }
            return Guid.Empty;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Descripcion: {0}\n", this.Descripcion);
            sb.AppendFormat("Codigo: {0}\n", this.codigo);
            sb.AppendFormat("Precio: ${0}\n", this.Precio);
            sb.AppendFormat("Stock: {0} unidades\n", this.Stock);
            return sb.ToString();
        }
    }
}
