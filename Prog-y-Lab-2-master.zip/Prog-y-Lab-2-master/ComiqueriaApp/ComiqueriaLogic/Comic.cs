﻿using System.Text;

namespace ComiqueriaLogic
{
    public class Comic : Producto
    {
        private string autor;
        private TipoComic tipoComic;

        public string Autor
        {
            get { return this.autor; }
        }

        public Comic(string descripcion, int stock,
            double precio, string autor, TipoComic tipo)
            : base(descripcion, stock, precio)
        {
            this.autor = autor;
            this.tipoComic = tipo;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("--------  Comic  --------");
            sb.AppendLine(base.ToString());
            sb.AppendFormat("Autor: {0}\n", this.Autor);
            sb.AppendFormat("Tipo de Comic: {0}", this.tipoComic.ToString());
            return sb.ToString();
        }

        public enum TipoComic
        {
            Occidental, Oriental
        }
    }
}
