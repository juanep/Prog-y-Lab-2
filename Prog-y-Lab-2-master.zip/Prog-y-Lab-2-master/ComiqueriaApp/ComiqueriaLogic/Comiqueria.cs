﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class Comiqueria
    {
        private List<Producto> productos;
        private List<Venta> ventas;

        public Producto this[Guid codigo]
        {
            get
            {
                foreach (Producto p in this.productos)
                {
                    if (codigo.Equals((Guid)p))
                    {
                        return p;
                    }
                }
                return null;
            }
        }

        public Comiqueria()
        {
            this.productos = new List<Producto>();
            this.ventas = new List<Venta>();
        }

        public static bool operator ==(Comiqueria comiqueria, Producto producto)
        {
            foreach (Producto p in comiqueria.productos)
            {
                if (p.Descripcion.Equals(producto.Descripcion))
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Comiqueria comiqueria, Producto producto)
        {
            return !(comiqueria == producto);
        }

        // override object.Equals
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }
            return base.Equals(obj);
        }

        // override object.GetHashCode
        public override int GetHashCode()
        {
            // TODO: write your implementation of GetHashCode() here
            return base.GetHashCode();
        }

        public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
        {
            if (comiqueria != producto)
            {
                comiqueria.productos.Add(producto);
            }
            return comiqueria;
        }

        public void Vender(Producto producto, int cantidad)
        {
            this.ventas.Add(new Venta(producto, cantidad));
        }

        public void Vender(Producto producto)
        {
            this.Vender(producto, 1);
        }

        public void SortByFecha()
        {
            this.ventas.Sort(Compare);
        }

        public int Compare(Venta x, Venta y)
        {
            return DateTime.Compare(y.Fecha, x.Fecha);
        }

        public string ListarVentas()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("-------  Ventas  -------");
            this.SortByFecha();
            foreach (Venta venta in this.ventas)
            {
                sb.AppendLine(venta.ObtenerDescripcionBreve());
            }
            return sb.ToString();
        }

        public Dictionary<Guid, string> ListarProductos()
        {
            Dictionary<Guid, string> dictionary = new Dictionary<Guid, string>();
            foreach (Producto p in this.productos)
            {
                dictionary.Add((Guid)p, p.Descripcion);
            }
            return dictionary;
        }
    }
}
