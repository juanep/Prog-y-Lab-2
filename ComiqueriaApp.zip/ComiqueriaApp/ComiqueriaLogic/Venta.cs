﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public sealed class Venta
    {
        private DateTime fecha;
        private static int porcentajeIva;
        private double precioFinal;
        private Producto producto;

        public DateTime Fecha
        {
            get { return this.fecha; }
            set { fecha = value; }
        }

        public static double CalcularPrecioFinal(double precioUnidad, int cantidad)
        {
            double final = 0;
            if (precioUnidad > 0 && cantidad > 0)
            {
                double iva = (precioUnidad * cantidad) * (Venta.porcentajeIva / 100);
                final = (precioUnidad * cantidad) + iva;
            }
            return final;
        }

        public string ObtenerDescripcionBreve()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0} -", this.Fecha.ToString());
            sb.AppendFormat("{0} -", this.producto.Descripcion);
            sb.AppendFormat("{0:N2}", this.precioFinal);
            return sb.ToString();
        }

        private void Vender(int cantidad)
        {
            if (cantidad > 0)
            {
                this.producto.Stock -= cantidad;
            }
            this.fecha = DateTime.Now;
            this.precioFinal = CalcularPrecioFinal(this.producto.Precio, cantidad);
        }

        static Venta()
        {
            Venta.porcentajeIva = 21;
        }

        internal Venta(Producto producto, int cantidad)
        {
            this.producto = producto;
            this.Vender(cantidad);
        }

    }
}
