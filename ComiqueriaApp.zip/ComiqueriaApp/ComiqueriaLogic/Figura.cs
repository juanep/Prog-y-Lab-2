﻿using System.Text;

namespace ComiqueriaLogic
{
    public class Figura : Producto
    {
        private double altura;

        public double Altura
        {
            get { return this.altura; }
        }

        public Figura(int stock, double precio, double altura)
            : base("", stock, precio)
        {
            this.altura = altura;
        }

        public Figura(string descripcion, int stock, double precio, double altura)
            : base(descripcion, stock, precio)
        {
            this.altura = altura;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("--------  Figura  --------");
            sb.AppendLine(base.ToString());
            sb.AppendFormat("Altura: {0}", this.Altura);
            return sb.ToString();
        }
    }
}
