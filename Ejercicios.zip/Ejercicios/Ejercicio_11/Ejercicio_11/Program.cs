﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 11";
            int max = 100;
            int min = -100;
            int i = 1;
            int flag = 0;
            int maximo = 0;
            int minimo = 0;

            float promedio;
            int numero;
            int acumulador = 0;

            while (i < 11)
            {
                Console.WriteLine("Ingrese un numero mayor a -100 y menor a 100");
                if (int.TryParse(Console.ReadLine(), out numero))
                {
                    if (Validacion.Validar(numero, min, max))
                    {
                        if (flag == 0)
                        {
                            maximo = numero;
                            minimo = numero;
                            flag = 1;
                        }
                        if (numero < minimo)
                        {
                            minimo = numero;
                        }
                        if (numero > maximo)
                        {
                            maximo = numero;
                        }
                        acumulador = acumulador + numero;
                        i++;
                    }
                    else
                    {
                        Console.WriteLine("Ingrese un numero dentro de los parametro");
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese un numero");
                }
            }
            promedio = acumulador / (float)10;
            Console.WriteLine("El numero maximo es {0}", maximo);
            Console.WriteLine("El numero minimo es {0}", minimo);
            Console.WriteLine("El promedio es {0}", promedio);
            Console.Read();
        }
    }
}
