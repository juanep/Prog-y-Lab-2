﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    public class Alumno
    {
        #region Atributos
        private byte nota1;
        private byte nota2;
        private float notaFinal;
        public int legajo;
        public String nombre;
        public String apellido;
        #endregion

        #region Constructores
        /// <summary>
        /// Crea el objeto Alumno cargando los campos Nombre, Apellido y Legajo a travéz de parámetros
        /// </summary>
        /// <param name="nombre">Nombre del Alumno</param>
        /// <param name="apellido">Apellido del Alumno</param>
        /// <param name="legajo">Legajo del alumno</param>
        public Alumno(string nombre, string apellido, int legajo)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.legajo = legajo;
        }
        #endregion

        #region Métodos
        /// <summary>
        /// Carga las notas del Alumno.
        /// </summary>
        /// <param name="notaUno">Nota del Primer Parcial</param>
        /// <param name="notaDos">Nota del Segundo Parcial</param>
        public void Estudiar(byte notaUno, byte notaDos)
        {
            this.nota1 = notaUno;
            this.nota2 = notaDos;
        }

        public void CalcularFinal()
        {
            Random random = new Random();
            
            if(this.nota1 >= 4 && this.nota2 >= 4)
            {
                this.notaFinal = random.Next(4, 11);
            }
            else
            {
                this.notaFinal = -1;
            }
        }

        public String Mostrar()
        {
            string mostrar = string.Empty;
            mostrar += String.Format("Nombre: {0}\n", this.nombre);
            mostrar += String.Format("Apellido: {0}\n", this.apellido);
            mostrar += String.Format("Legajo: {0}\n", this.legajo);
            mostrar += String.Format("Nota Final: {0}\n", this.notaFinal);
            return mostrar;
        }
        #endregion
    }
}
