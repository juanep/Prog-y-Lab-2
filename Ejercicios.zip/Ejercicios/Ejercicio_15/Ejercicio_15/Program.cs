﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nº 15";

            int a;
            int b;
            int opcion;
            int resultado = 0;
            char respuesta;
            bool continuar = false;

            do
            {
                Console.WriteLine("Ingrese el primer numero");
                if (int.TryParse(Console.ReadLine(), out a))
                {
                    Console.WriteLine("Ingrese el segundo numero");
                    if (int.TryParse(Console.ReadLine(), out b))
                    {
                        Console.WriteLine("1. Suma");
                        Console.WriteLine("2. Resta");
                        Console.WriteLine("3. Multiplicacion");
                        Console.WriteLine("4. Division");
                        Console.WriteLine("La operacion que quiera hacer");
                        if (int.TryParse(Console.ReadLine(), out opcion))
                        {
                            switch (opcion)
                            {
                                case 1:
                                    resultado = Operacion.Sumar(a, b);
                                    break;
                                case 2:
                                    resultado = Operacion.Restar(a, b);
                                    break;
                                case 3:
                                    resultado = Operacion.Multiplicar(a, b);
                                    break;
                                case 4:
                                    resultado = (int)Operacion.Dividir(a, b);
                                    break;
                                default:
                                    Console.Write("Usted ingreso una opcion invalida");
                                    break;
                            }
                            Console.WriteLine("El resultado es {0}", resultado);
                            Console.WriteLine();
                            Console.WriteLine("Desea continuar? ");
                            if (char.TryParse(Console.ReadLine(), out respuesta))
                            {
                                continuar = Operacion.ValidarS_N(respuesta);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Usted ingreso una letra");
                            Console.WriteLine();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Usted ingreso una letra");
                        Console.WriteLine();
                    }
                }
                else
                {
                    Console.WriteLine("Usted ingreso una letra");
                    Console.WriteLine();
                }
            } while (continuar == true);
        }
    }
}
