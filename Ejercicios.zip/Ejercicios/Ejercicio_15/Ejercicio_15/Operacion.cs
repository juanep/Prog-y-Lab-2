﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    class Operacion
    {
        public static bool ValidarS_N(char respuesta)
        {
            bool retorno = false;
            if (respuesta.Equals('s') || respuesta.Equals('S'))
            {
                retorno = true;
            }
            return retorno;
        }

        public static int Sumar(int a, int b)
        {
            return a + b;
        }

        public static int Restar(int a, int b)
        {
            return a - b;
        }

        public static int Multiplicar(int a, int b)
        {
            return a * b;
        }

        public static float Dividir(int a, int b)
        {
            return a / (float)b;
        }
    }
}
