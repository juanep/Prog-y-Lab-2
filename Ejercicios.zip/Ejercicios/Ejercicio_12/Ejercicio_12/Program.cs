﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 12";
            int numero;
            int acumulador = 0;
            ConsoleKeyInfo respuesta;
            bool continuar = false;

            do
            {
                Console.WriteLine();
                Console.WriteLine("Ingrese un numero");
                if (int.TryParse(Console.ReadLine(), out numero))
                {
                    acumulador = acumulador + numero;
                    Console.WriteLine("Continuar(S/N)");
                    respuesta = Console.ReadKey();
                    continuar = ValidarRespuesta.ValidarS_N(respuesta.KeyChar);
                }
                else
                {
                    Console.WriteLine("Usted ingreso una letra");
                }
            } while (continuar == true);
            Console.WriteLine();
            Console.WriteLine("La suma de todos los numeros es {0}", acumulador);
            Console.ReadKey();
        }
    }
}
