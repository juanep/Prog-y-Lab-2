﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_9
{
    class Program
    {
        static void Main(string[] args)
        {
            int largo;
            bool continuar = true;
            int ancho = 1;

            do
            {
                Console.WriteLine("Ingrese el largo de la piramide");
                if (int.TryParse(Console.ReadLine(), out largo))
                {
                    for (int i = 0; i < largo; i++)
                    {
                        for (int j = 0; j < ancho; j++)
                        {
                            Console.Write("*");
                        }
                        ancho = ancho + 2;
                        Console.WriteLine();
                    }
                    continuar = false;
                }
            } while (continuar);
            Console.Read();
        }
    }
}
