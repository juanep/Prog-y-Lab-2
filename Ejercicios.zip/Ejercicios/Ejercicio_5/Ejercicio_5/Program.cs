﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 5";
            int numero;
            int contador = 0;
            Boolean condicion = true;

            do
            {
                Console.Write("Ingrese un numero");
                if (int.TryParse(Console.ReadLine(), out numero))
                {

                }
            } while (condicion);
        }
    }
}
