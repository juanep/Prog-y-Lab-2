﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 1";
            int num;
            int flag = 1;
            int acumulador = 0;
            float promedio;
            int max = 0;
            int min = 0;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("ingrese un numero");
                if (int.TryParse(Console.ReadLine(), out num))
                {
                    if (flag == 1)
                    {
                        max = num;
                        min = num;
                        flag = 0;
                    }
                    if (num > max)
                    {
                        max = num;
                    }
                    if (num < min)
                    {
                        min = num;
                    }
                    acumulador = acumulador + num;
                }
                else
                {
                    i--;
                }
            }
            promedio = acumulador / 5;

            Console.WriteLine("numero maximo es {0}", max);
            Console.WriteLine("numero minimo es {0}", min);
            Console.WriteLine("el promedio es {0}", promedio);
            Console.ReadLine();
        }
    }
}
