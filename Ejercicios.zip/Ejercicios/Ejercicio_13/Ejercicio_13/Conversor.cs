﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13
{
    class Conversor
    {
        public static double BinarioDecimal(string num)
        {
            return Convert.ToInt64(num, 2);
        }

        public static string DecimalBinario(double num)
        {
            return Convert.ToString(Convert.ToByte(num), 2);
        }
    }
}
