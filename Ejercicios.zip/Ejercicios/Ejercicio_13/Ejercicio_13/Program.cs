﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 13";

            string binario = "";
            double numeroDecimal = 0;
            Console.WriteLine("Ingrese un numero decimal:");
            numeroDecimal = double.Parse(Console.ReadLine());
            Console.WriteLine(numeroDecimal + " = " + Conversor.DecimalBinario(numeroDecimal));
            Console.WriteLine("Ingrese un numero binario:");
            binario = Console.ReadLine();
            Console.WriteLine(binario + " = " + Conversor.BinarioDecimal(binario));
            Console.Read();
        }
    }
}
