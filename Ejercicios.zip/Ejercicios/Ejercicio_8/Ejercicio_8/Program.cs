﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_8
{
    class Program
    {
        static void Main(string[] args)
        {
            int valorHora;
            int antiguedad;
            int horasTrabajadas;
            float bruto = 0;
            float neto = 0;
            String nombre = "";
            bool continuar = true;

            do
            {
                Console.WriteLine("Ingrese el valor hora del empleado");
                if (int.TryParse(Console.ReadLine(), out valorHora))
                {
                    Console.WriteLine("Ingrese la antiguedad del empleado");
                    if (int.TryParse(Console.ReadLine(), out antiguedad))
                    {
                        Console.WriteLine("Ingrese las horas trabajadas del empleado");
                        if (int.TryParse(Console.ReadLine(), out horasTrabajadas))
                        {
                            bruto = horasTrabajadas * valorHora + antiguedad * 150;
                            neto = bruto * (float)0.87;
                            continuar = false;
                            Console.WriteLine("Ingrese el nombre del empleado");
                            nombre = Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Las horas tienen que ser numericas");
                        }
                    }
                    else
                    {
                        Console.WriteLine("La antiguedad tiene que ser un numero");
                    }
                }
                else
                {
                    Console.WriteLine("El valor hora tiene que ser numerico");
                    Console.WriteLine();
                }
            } while (continuar);
            Console.WriteLine("Empleado = {0}", nombre);
            Console.WriteLine("Bruto = {0}", bruto);
            Console.WriteLine("Neto = {0}", neto);
            Console.Read();
        }
    }
}
