﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 2";
            Boolean condicion = true;
            int numero;
            do
            {
                Console.WriteLine("Ingrese un numero: ");
                if (int.TryParse(Console.ReadLine(), out numero))
                {
                    if (numero <= 0)
                    {
                        Console.WriteLine("ERROR ¡REINGRESE EL NUMERO!");
                        Console.Read();
                    }
                    else
                    {
                        condicion = false;
                        Console.WriteLine("El cuadrado del numero es {0}", Math.Pow(numero, 2));
                        Console.WriteLine("El cubo del numero es {0}", Math.Pow(numero, 3));
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese un numero!!!!!!!!!!!");
                }
            } while (condicion);
            Console.Read();
        }
    }
}
