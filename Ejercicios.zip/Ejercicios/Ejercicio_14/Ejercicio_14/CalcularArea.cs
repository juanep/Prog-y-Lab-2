﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    class CalcularArea
    {
        public static double Cuadrado(double lado)
        {
            return lado * 4;
        }

        public static double Triangulo(double lado, double altura)
        {
            return ((lado * altura) / 2);
        }

        public static double Circulo(double radio)
        {
            return (3.16 * radio * radio);
        }
    }
}
