﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 14";
            double lado;
            double altura;

            int ladoInt;
            int alturaInt;

            int opcion;

            double area = 0;
            bool continuar = true;

            do
            {
                Console.WriteLine("Ingrese el tipo de figura que quiere calcular");
                Console.WriteLine("1. Cuadrado");
                Console.WriteLine("2. Triangulo");
                Console.WriteLine("3. Circulo");
                Console.WriteLine("Su opcion: ");
                if (int.TryParse(Console.ReadLine(), out opcion))
                {
                    switch (opcion)
                    {
                        case 1:
                            Console.WriteLine("Ingrese el valor del lado");
                            if (int.TryParse(Console.ReadLine(), out ladoInt))
                            {
                                lado = ladoInt;
                                area = CalcularArea.Cuadrado(lado);
                                continuar = false;
                            }
                            else
                            {
                                Console.WriteLine("Usted ingreso una letra");
                                Console.WriteLine();
                            }
                            break;

                        case 2:
                            Console.WriteLine("Ingrese el valor de la base");
                            if (int.TryParse(Console.ReadLine(), out ladoInt))
                            {
                                Console.WriteLine("Ingrese el valor de la altura");
                                if (int.TryParse(Console.ReadLine(), out alturaInt))
                                {
                                    lado = ladoInt;
                                    altura = alturaInt;
                                    area = CalcularArea.Triangulo(lado, altura);
                                    continuar = false;
                                }
                                else
                                {
                                    Console.WriteLine("Usted ingreso una letra");
                                    Console.WriteLine();
                                }
                            }
                            else
                            {
                                Console.WriteLine("Usted ingreso una letra");
                                Console.WriteLine();
                            }
                            break;

                        case 3:
                            Console.WriteLine("Ingrese el valor del radio");
                            if (int.TryParse(Console.ReadLine(), out ladoInt))
                            {
                                lado = ladoInt;
                                area = CalcularArea.Circulo(lado);
                                continuar = false;
                            }
                            else
                            {
                                Console.WriteLine("Usted ingreso una letra");
                                Console.WriteLine();
                            }
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Usted ingreso una letra");
                    Console.WriteLine();
                }
            } while (continuar);
            Console.WriteLine("El valor del area es {0}", area);
            Console.Read();
        }
    }
}
