﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 4";
            int contador = 0;
            int numero = 1;
            int acumulador = 0;

            while (contador < 4)
            {
                for (int i = 1; i != numero; i++)
                {
                    if (numero % i == 0)
                    {
                        acumulador = acumulador + i;
                    }
                }
                if (acumulador == numero)
                {
                    contador++;
                    Console.WriteLine("el numero {0} es perfecto", numero);
                }
                numero++;
                acumulador = 0;
            }
            Console.Read();
        }
    }
}
