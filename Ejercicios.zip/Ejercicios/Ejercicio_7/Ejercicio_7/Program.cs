﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 7";
            int añoActual = DateTime.Now.Year;
            int mesActual = DateTime.Now.Month;
            int diaActual = DateTime.Now.Day;

            int diaNacimiento;
            int mesNacimiento;
            int añoNacimiento;

            int acumulador = 0;

            Boolean condicion = true;

            do
            {
                Console.WriteLine("Ingrese su dia de nacimiento");
                if (int.TryParse(Console.ReadLine(), out diaNacimiento))
                {
                    Console.WriteLine("Ingrese el mes de nacimiento");
                    if (int.TryParse(Console.ReadLine(), out mesNacimiento))
                    {
                        Console.WriteLine("Ingrese el año de nacimiento");
                        if (int.TryParse(Console.ReadLine(), out añoNacimiento))
                        {
                            condicion = false;
                            if (diaNacimiento < diaActual)
                            {
                                for (int i = diaNacimiento; i != diaActual; i++)
                                {
                                    acumulador++;
                                }
                            }
                            else
                            {
                                for (int i = diaNacimiento; i != diaActual; i++)
                                {
                                    if (i == 31)
                                    {
                                        i = 1;
                                        mesNacimiento++;
                                    }
                                    acumulador++;
                                }
                            }

                            if (mesNacimiento < mesActual)
                            {
                                for (int i = mesNacimiento; i != mesActual; i++)
                                {
                                    acumulador = acumulador + 31;
                                }
                            }
                            else
                            {
                                for (int i = mesNacimiento; i != mesActual; i++)
                                {
                                    if (i == 12)
                                    {
                                        i = 1;
                                        añoNacimiento++;
                                    }
                                    acumulador = acumulador + 31;
                                }
                            }


                            for (int i = añoNacimiento; i != añoActual; i++)
                            {
                                acumulador = acumulador + 365;
                                if (i % 4 == 0)
                                {
                                    acumulador++;
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("El año tiene que ser numerico");
                        }
                    }
                    else
                    {
                        Console.WriteLine("el mes tiene que ser numerico");
                    }
                }
                else
                {
                    Console.WriteLine("El dia tiene que ser numerico");
                }
            } while (condicion);
            Console.Write("usted vivio {0} dia", acumulador);
            Console.Read();
        }
    }
}
