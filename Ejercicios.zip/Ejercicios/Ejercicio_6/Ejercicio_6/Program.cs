﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 6";
            int primerAño;
            int segundoAño;
            Boolean condicion = true;

            do
            {
                Console.WriteLine("Ingrese el primer año: ");
                if (int.TryParse(Console.ReadLine(), out primerAño))
                {
                    Console.WriteLine("Ingrese el segundo año: ");
                    if (int.TryParse(Console.ReadLine(), out segundoAño))
                    {
                        condicion = false;
                        Console.WriteLine("Los años viciestos son: ");
                        for (int i = primerAño; i != segundoAño; i++)
                        {
                            if (i % 4 == 0)
                            {
                                Console.WriteLine(i);
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("El año tiene que ser numerico");
                    }
                }
                else
                {
                    Console.WriteLine("El año tiene que ser numerico");
                }
            } while (condicion);
            Console.Read();
        }
    }
}
