﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita
    {
        private List<Llamada> llamadas;
        static string razonSocial;

        public float GananciasPorLocal
        {
            get
            {

            }
        }

        public float CalcularGanancia(Llamada.TipoLlamada tipoLlamada)
        {
            float ganancia = 0F;
            foreach(Llamada llamada in this.llamadas)
            {
                if(llamada is Local)
                {
                    ganancia += llamada.Duracion * ;
                }
            }
            return ganancia;
        }
    }
}
